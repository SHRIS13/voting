<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Minor Project</b>
    </div>
    <strong>Tech Culture; 2022 <a href="https://svvv.edu.in">Shri Vaishnav Vidyapeeth Vishwavidhyalaya</a></strong>
</footer>