	  <hr>

      <footer>
        <div class="foot_center3"><p>Copyright &copy; 2012 CHMSC laboratory School</p>
		<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbspProgrammed by: John Kevin Lorayna :-P</p>
		</div>
      </footer>