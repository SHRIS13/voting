<?php
	$connection = mysqli_connect('localhost','root','') or die(mysqli_error());
	mysqli_select_db('capstone') or die(mysqli_error());
?>
