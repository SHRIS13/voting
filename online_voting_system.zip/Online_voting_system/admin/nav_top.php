	<div class="navbar navbar-fixed-top">
	<div class="navbar-inner">
	<div class="container">
	     
		<a class="brand">
		<img src="images/chmsc.png" width="60" height="60">
 	</a>
	<a class="brand">
	 <h2>CHMSC Laboratory School Voting System</h2>
	 <div class="chmsc_nav"><font size="4" color="white">Carlos Hilado Memorial State College</font></div>
 	</a>

	<?php include('head.php'); ?>
 
 
	</div>
	</div>
	</div>
	